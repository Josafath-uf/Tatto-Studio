/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Courgette", "Inter", "ui-sans-serif", "system-ui"],
      },
      colors: {
        ink: "#050805",
        carbon: "#0b100c",
        limecraft: "#ff2d2d",
        mist: "#f4f7ef",
      },
      boxShadow: {
        lime: "0 0 0 1px rgba(255,45,45,.25), 0 24px 80px rgba(255,45,45,.12)",
      },
    },
  },
  plugins: [],
};
